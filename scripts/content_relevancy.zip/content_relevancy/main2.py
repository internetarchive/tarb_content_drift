from bs4 import BeautifulSoup
import requests
from similarity.similarity import bert_similarity, combined_similarity
from summarization.summarization import summarize
from utils.utils import print_boxed_info


def scrape_content(url: str) -> str:
    response = requests.get(url)
    if response.status_code != 200:
        print(f"Failed to retrieve content from {url}")
        return ""
    soup = BeautifulSoup(response.text, "html.parser")
    return " ".join([p.text for p in soup.find_all("p")])


def get_content_relevancy(wikipedia_url: str, embedded_url: str):
    results = []

    wikipedia_content = scrape_content(wikipedia_url)
    embedded_content = scrape_content(embedded_url)

    if not wikipedia_content or not embedded_content:
        print("Failed to retrieve content for one or both URLs.")
        return

    wikipedia_summary, embedded_summary = summarize(
        [wikipedia_content, embedded_content]
    )

    # Calculate similarity scores
    bert_relevancy = bert_similarity(wikipedia_summary, embedded_summary)
    combined_relevancy = combined_similarity(wikipedia_summary, embedded_summary)

    # Print the information
    print_boxed_info(
        wikipedia_url,
        embedded_url,
        wikipedia_summary,
        embedded_summary,
        bert_relevancy,
        combined_relevancy,
    )

    results.append((wikipedia_url, combined_relevancy))

    return results


wikipedia_url = "https://en.wikipedia.org/wiki/Ilhan_Kyuchyuk"
embedded_url = "https://neweasterneurope.eu/2023/04/17/security-and-enlargement-two-sides-of-the-same-coin/"
results = get_content_relevancy(wikipedia_url, embedded_url)


print(results)
